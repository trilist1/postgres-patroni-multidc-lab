#!/usr/bin/env python3
"""
Unified generator for postgres_exporter queries.yml and Grafana dashboard JSON.
Runs inside a Docker python:3-slim container during setup.
Produces clean YAML/JSON with LF line endings - no CMD echo corruption.
"""
import json, yaml, sys, os

QUERIES_OUT = sys.argv[1] if len(sys.argv) > 1 else "/out/queries.yml"
DASHBOARD_OUT = sys.argv[2] if len(sys.argv) > 2 else "/out/pg-ha-cluster.json"

# ===========================================================================
# POSTGRES EXPORTER CUSTOM QUERIES
# Each top-level key becomes a metric namespace prefix, e.g. pg_replication_*
# IMPORTANT: No pg_stat_statements - it causes HTTP 500 if extension missing.
# The post_setup step creates the extension, but replicas may not have it
# immediately. Instead we rely on Patroni's built-in /metrics which already
# exposes useful query stats.
# ===========================================================================
queries = {
    "pg_replication": {
        "query": """
            SELECT
                CASE WHEN NOT pg_is_in_recovery() THEN 0
                     ELSE GREATEST(0, EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp())))
                END AS lag_seconds,
                CASE WHEN pg_is_in_recovery() THEN 1 ELSE 0 END AS is_replica,
                CASE WHEN pg_is_in_recovery()
                     THEN pg_last_wal_receive_lsn() - '0/0'
                     ELSE pg_current_wal_lsn() - '0/0'
                END AS wal_position_bytes
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"lag_seconds": {"usage": "GAUGE", "description": "Replication lag in seconds (0 on primary)"}},
            {"is_replica": {"usage": "GAUGE", "description": "1 if replica, 0 if primary"}},
            {"wal_position_bytes": {"usage": "GAUGE", "description": "Current WAL position in bytes"}},
        ]
    },
    "pg_stat_replication_detail": {
        "query": """
            SELECT
                COALESCE(client_addr::text, 'local') AS client_addr,
                application_name,
                state,
                sync_state,
                COALESCE(sent_lsn - replay_lsn, 0) AS replay_lag_bytes,
                COALESCE(sent_lsn - write_lsn, 0) AS write_lag_bytes,
                COALESCE(sent_lsn - flush_lsn, 0) AS flush_lag_bytes
            FROM pg_stat_replication
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"client_addr": {"usage": "LABEL", "description": "Replica IP"}},
            {"application_name": {"usage": "LABEL", "description": "Replica name"}},
            {"state": {"usage": "LABEL", "description": "Replication state"}},
            {"sync_state": {"usage": "LABEL", "description": "Sync mode"}},
            {"replay_lag_bytes": {"usage": "GAUGE", "description": "Replay lag bytes"}},
            {"write_lag_bytes": {"usage": "GAUGE", "description": "Write lag bytes"}},
            {"flush_lag_bytes": {"usage": "GAUGE", "description": "Flush lag bytes"}},
        ]
    },
    "pg_database_activity": {
        "query": """
            SELECT
                datname,
                numbackends AS connections,
                xact_commit AS commits,
                xact_rollback AS rollbacks,
                blks_read,
                blks_hit,
                tup_returned,
                tup_fetched,
                tup_inserted,
                tup_updated,
                tup_deleted,
                conflicts,
                temp_files,
                temp_bytes,
                deadlocks,
                COALESCE(blks_hit::float / NULLIF(blks_hit + blks_read, 0) * 100, 0) AS cache_hit_ratio
            FROM pg_stat_database
            WHERE datname NOT LIKE 'template%%'
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"datname": {"usage": "LABEL"}},
            {"connections": {"usage": "GAUGE", "description": "Active connections"}},
            {"commits": {"usage": "COUNTER", "description": "Transactions committed"}},
            {"rollbacks": {"usage": "COUNTER", "description": "Transactions rolled back"}},
            {"blks_read": {"usage": "COUNTER", "description": "Blocks read from disk"}},
            {"blks_hit": {"usage": "COUNTER", "description": "Blocks hit in buffer cache"}},
            {"tup_returned": {"usage": "COUNTER", "description": "Rows returned"}},
            {"tup_fetched": {"usage": "COUNTER", "description": "Rows fetched"}},
            {"tup_inserted": {"usage": "COUNTER", "description": "Rows inserted"}},
            {"tup_updated": {"usage": "COUNTER", "description": "Rows updated"}},
            {"tup_deleted": {"usage": "COUNTER", "description": "Rows deleted"}},
            {"conflicts": {"usage": "COUNTER", "description": "Replication conflicts"}},
            {"temp_files": {"usage": "COUNTER", "description": "Temp files created"}},
            {"temp_bytes": {"usage": "COUNTER", "description": "Temp bytes written"}},
            {"deadlocks": {"usage": "COUNTER", "description": "Deadlocks detected"}},
            {"cache_hit_ratio": {"usage": "GAUGE", "description": "Buffer cache hit ratio pct"}},
        ]
    },
    "pg_locks_summary": {
        "query": """
            SELECT
                d.datname,
                l.mode,
                COUNT(*) AS count
            FROM pg_locks l
            JOIN pg_database d ON l.database = d.oid
            GROUP BY d.datname, l.mode
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"datname": {"usage": "LABEL"}},
            {"mode": {"usage": "LABEL"}},
            {"count": {"usage": "GAUGE", "description": "Lock count by mode"}},
        ]
    },
    "pg_table_stats": {
        "query": """
            SELECT
                schemaname,
                relname,
                seq_scan,
                idx_scan,
                n_tup_ins,
                n_tup_upd,
                n_tup_del,
                n_tup_hot_upd,
                n_live_tup,
                n_dead_tup,
                vacuum_count,
                autovacuum_count,
                analyze_count,
                autoanalyze_count
            FROM pg_stat_user_tables
            ORDER BY n_dead_tup DESC
            LIMIT 50
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"schemaname": {"usage": "LABEL"}},
            {"relname": {"usage": "LABEL"}},
            {"seq_scan": {"usage": "COUNTER", "description": "Sequential scans"}},
            {"idx_scan": {"usage": "COUNTER", "description": "Index scans"}},
            {"n_tup_ins": {"usage": "COUNTER", "description": "Rows inserted"}},
            {"n_tup_upd": {"usage": "COUNTER", "description": "Rows updated"}},
            {"n_tup_del": {"usage": "COUNTER", "description": "Rows deleted"}},
            {"n_tup_hot_upd": {"usage": "COUNTER", "description": "HOT updates"}},
            {"n_live_tup": {"usage": "GAUGE", "description": "Live rows"}},
            {"n_dead_tup": {"usage": "GAUGE", "description": "Dead rows"}},
            {"vacuum_count": {"usage": "COUNTER", "description": "Manual vacuums"}},
            {"autovacuum_count": {"usage": "COUNTER", "description": "Auto vacuums"}},
            {"analyze_count": {"usage": "COUNTER", "description": "Manual analyzes"}},
            {"autoanalyze_count": {"usage": "COUNTER", "description": "Auto analyzes"}},
        ]
    },
    "pg_table_sizes": {
        "query": """
            SELECT
                schemaname,
                relname,
                pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)) AS total_bytes,
                pg_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)) AS table_bytes,
                pg_indexes_size(quote_ident(schemaname) || '.' || quote_ident(relname)) AS index_bytes
            FROM pg_stat_user_tables
            ORDER BY pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)) DESC
            LIMIT 30
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"schemaname": {"usage": "LABEL"}},
            {"relname": {"usage": "LABEL"}},
            {"total_bytes": {"usage": "GAUGE", "description": "Total table+index size"}},
            {"table_bytes": {"usage": "GAUGE", "description": "Table heap size"}},
            {"index_bytes": {"usage": "GAUGE", "description": "Index size"}},
        ]
    },
    "pg_wal_info": {
        "query": "SELECT count(*) AS file_count, sum(size) AS total_bytes FROM pg_ls_waldir()",
        "master": True,
        "metrics": [
            {"file_count": {"usage": "GAUGE", "description": "WAL files on disk"}},
            {"total_bytes": {"usage": "GAUGE", "description": "Total WAL size bytes"}},
        ]
    },
    "pg_connection_states": {
        "query": """
            SELECT
                datname,
                state,
                COUNT(*) AS count
            FROM pg_stat_activity
            WHERE datname IS NOT NULL
            GROUP BY datname, state
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"datname": {"usage": "LABEL"}},
            {"state": {"usage": "LABEL"}},
            {"count": {"usage": "GAUGE", "description": "Connections by state"}},
        ]
    },
    "pg_longest_query": {
        "query": """
            SELECT
                COALESCE(MAX(EXTRACT(EPOCH FROM (now() - query_start))), 0) AS max_duration_seconds
            FROM pg_stat_activity
            WHERE state = 'active' AND query NOT LIKE 'autovacuum%%'
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"max_duration_seconds": {"usage": "GAUGE", "description": "Longest running query seconds"}},
        ]
    },
    "pg_settings_info": {
        "query": """
            SELECT
                current_setting('max_connections')::int AS max_connections,
                current_setting('shared_buffers') AS shared_buffers,
                current_setting('work_mem') AS work_mem
        """.strip().replace("\n", " "),
        "master": True,
        "metrics": [
            {"max_connections": {"usage": "GAUGE", "description": "max_connections setting"}},
            {"shared_buffers": {"usage": "LABEL"}},
            {"work_mem": {"usage": "LABEL"}},
        ]
    },
}

# Write queries.yml
os.makedirs(os.path.dirname(QUERIES_OUT), exist_ok=True)
with open(QUERIES_OUT, 'w', newline='\n') as f:
    yaml.dump(queries, f, default_flow_style=False, sort_keys=False, allow_unicode=True, width=10000)
print(f"queries.yml: {len(queries)} custom query namespaces written to {QUERIES_OUT}")


# ===========================================================================
# GRAFANA DASHBOARD
# Uses ONLY metrics that are guaranteed to exist:
# - patroni_* metrics from Patroni REST API /metrics (always available)
# - pg_* default metrics from postgres_exporter (always available)
# - pg_*_custom metrics from our queries.yml above
# ===========================================================================

DS = {"type": "prometheus", "uid": "${DS_PROMETHEUS}"}

def P(title, ptype, gx, gy, gw, gh, targets, **kw):
    p = {"title": title, "type": ptype, "gridPos": {"h": gh, "w": gw, "x": gx, "y": gy}, "targets": targets, "datasource": DS}
    for k in ("fieldConfig", "options", "description"):
        if k in kw: p[k] = kw[k]
    return p

def T(expr, legend="", ref="A", fmt="time_series", instant=False):
    t = {"expr": expr, "refId": ref}
    if legend: t["legendFormat"] = legend
    if fmt != "time_series": t["format"] = fmt
    if instant: t["instant"] = True
    return t

def R(title, y):
    return {"type": "row", "title": title, "gridPos": {"h": 1, "w": 24, "x": 0, "y": y}, "collapsed": False, "panels": []}

def FC(unit=None, decimals=None, thr=None, mappings=None, mn=None, mx=None):
    d = {}
    if unit: d["unit"] = unit
    if decimals is not None: d["decimals"] = decimals
    if thr: d["thresholds"] = {"mode": "absolute", "steps": thr}
    if mappings: d["mappings"] = mappings
    if mn is not None: d["min"] = mn
    if mx is not None: d["max"] = mx
    return {"defaults": d, "overrides": []}

panels = []
y = 0

# === ROW: CLUSTER OVERVIEW (Patroni metrics - always available) ===
panels.append(R("CLUSTER OVERVIEW", y)); y += 1

panels.append(P("Patroni Cluster Members", "table", 0, y, 24, 5,
    [T("patroni_patroni_info", fmt="table", instant=True)])); y += 5

sm = [{"type": "value", "options": {"1": {"text": "RUNNING", "color": "green"}, "0": {"text": "STOPPED", "color": "red"}}}]
panels.append(P("patroni1", "stat", 0, y, 4, 4, [T('patroni_running{instance=~"patroni1.*"}', "patroni1")], fieldConfig=FC(mappings=sm)))
panels.append(P("patroni2", "stat", 4, y, 4, 4, [T('patroni_running{instance=~"patroni2.*"}', "patroni2")], fieldConfig=FC(mappings=sm)))
panels.append(P("patroni3", "stat", 8, y, 4, 4, [T('patroni_running{instance=~"patroni3.*"}', "patroni3")], fieldConfig=FC(mappings=sm)))

panels.append(P("Timeline", "stat", 12, y, 4, 4,
    [T("patroni_timeline", "{{instance}}")],
    fieldConfig=FC(decimals=0, thr=[{"color": "blue", "value": None}])))

pm = [{"type": "value", "options": {"1": {"text": "PRIMARY", "color": "green"}, "0": {"text": "REPLICA", "color": "blue"}}}]
panels.append(P("Leader", "stat", 16, y, 4, 4, [T("patroni_primary", "{{instance}}")], fieldConfig=FC(mappings=pm)))

panels.append(P("PostgreSQL Version", "stat", 20, y, 4, 4,
    [T("patroni_server_version", "{{instance}}")],
    fieldConfig=FC(decimals=0))); y += 4

# === ROW: REPLICATION ===
panels.append(R("REPLICATION", y)); y += 1

panels.append(P("WAL Position (Patroni)", "timeseries", 0, y, 8, 7,
    [T("patroni_xlog_replayed_location", "replay {{instance}}", "A"),
     T("patroni_xlog_received_location", "received {{instance}}", "B"),
     T("patroni_xlog_location", "primary {{instance}}", "C")],
    fieldConfig=FC(unit="bytes"),
    description="WAL positions from Patroni metrics (always available)"))

panels.append(P("Replication Lag (custom exporter)", "timeseries", 8, y, 8, 7,
    [T("pg_replication_lag_seconds", "{{pg_node}}")],
    fieldConfig=FC(unit="s", thr=[{"color":"green","value":None},{"color":"yellow","value":1},{"color":"red","value":10}]),
    description="From custom query pg_replication"))

panels.append(P("WAL Files on Disk", "timeseries", 16, y, 8, 7,
    [T("pg_wal_info_file_count", "{{pg_node}}")],
    description="WAL segment count per node")); y += 7

panels.append(P("Replication Detail (primary view)", "table", 0, y, 12, 6,
    [T("pg_stat_replication_detail_replay_lag_bytes", fmt="table", instant=True, legend="{{application_name}}")],
    description="Per-replica lag from primary's pg_stat_replication"))

panels.append(P("WAL Total Size per Node", "timeseries", 12, y, 12, 6,
    [T("pg_wal_info_total_bytes", "{{pg_node}}")],
    fieldConfig=FC(unit="bytes"))); y += 6

# === ROW: DATABASE ACTIVITY (custom exporter metrics) ===
panels.append(R("DATABASE ACTIVITY", y)); y += 1

panels.append(P("Connections by Database/State", "timeseries", 0, y, 8, 7,
    [T("pg_connection_states_count", "{{pg_node}} {{datname}} {{state}}")],
    description="From custom pg_connection_states query"))

panels.append(P("Transactions per Second", "timeseries", 8, y, 8, 7,
    [T("rate(pg_database_activity_commits[5m])", "commits {{pg_node}} {{datname}}", "A"),
     T("rate(pg_database_activity_rollbacks[5m])", "rollbacks {{pg_node}} {{datname}}", "B")],
    fieldConfig=FC(unit="ops")))

panels.append(P("Total Connections per Node", "gauge", 16, y, 8, 7,
    [T("pg_database_activity_connections", "{{pg_node}} {{datname}}")],
    fieldConfig=FC(mn=0, mx=200, thr=[{"color":"green","value":None},{"color":"yellow","value":100},{"color":"red","value":180}]))); y += 7

panels.append(P("Rows Inserted/Updated/Deleted per Sec", "timeseries", 0, y, 12, 7,
    [T("rate(pg_database_activity_tup_inserted[5m])", "ins {{pg_node}} {{datname}}", "A"),
     T("rate(pg_database_activity_tup_updated[5m])", "upd {{pg_node}} {{datname}}", "B"),
     T("rate(pg_database_activity_tup_deleted[5m])", "del {{pg_node}} {{datname}}", "C")],
    fieldConfig=FC(unit="ops")))

panels.append(P("Rows Fetched/Returned per Sec", "timeseries", 12, y, 12, 7,
    [T("rate(pg_database_activity_tup_fetched[5m])", "fetched {{pg_node}} {{datname}}", "A"),
     T("rate(pg_database_activity_tup_returned[5m])", "returned {{pg_node}} {{datname}}", "B")],
    fieldConfig=FC(unit="ops"))); y += 7

# === ROW: PERFORMANCE ===
panels.append(R("PERFORMANCE", y)); y += 1

panels.append(P("Cache Hit Ratio per Database", "gauge", 0, y, 8, 7,
    [T("pg_database_activity_cache_hit_ratio", "{{pg_node}} {{datname}}")],
    fieldConfig=FC(unit="percent", mn=0, mx=100, decimals=2,
        thr=[{"color":"red","value":None},{"color":"yellow","value":90},{"color":"green","value":99}]),
    description="Buffer cache hit ratio - should be >99%"))

panels.append(P("Block I/O Rate", "timeseries", 8, y, 8, 7,
    [T("rate(pg_database_activity_blks_hit[5m])", "hits {{pg_node}} {{datname}}", "A"),
     T("rate(pg_database_activity_blks_read[5m])", "reads {{pg_node}} {{datname}}", "B")],
    fieldConfig=FC(unit="ops"),
    description="Buffer cache hits vs disk reads"))

panels.append(P("Temp File Usage", "timeseries", 16, y, 8, 7,
    [T("rate(pg_database_activity_temp_bytes[5m])", "{{pg_node}} {{datname}}")],
    fieldConfig=FC(unit="bytes"),
    description="High values indicate work_mem too low")); y += 7

panels.append(P("Checkpoints (default exporter)", "timeseries", 0, y, 8, 7,
    [T("rate(pg_stat_bgwriter_checkpoints_timed_total[5m])", "timed {{instance}}", "A"),
     T("rate(pg_stat_bgwriter_checkpoints_req_total[5m])", "requested {{instance}}", "B")],
    fieldConfig=FC(unit="ops"),
    description="Timed=normal Requested=forced. From default exporter metrics."))

panels.append(P("Buffer Writes by Source", "timeseries", 8, y, 8, 7,
    [T("rate(pg_stat_bgwriter_buffers_checkpoint_total[5m])", "checkpoint {{instance}}", "A"),
     T("rate(pg_stat_bgwriter_buffers_clean_total[5m])", "bgwriter {{instance}}", "B"),
     T("rate(pg_stat_bgwriter_buffers_backend_total[5m])", "backend {{instance}}", "C")],
    fieldConfig=FC(unit="ops"),
    description="High 'backend' = shared_buffers pressure"))

panels.append(P("Longest Running Query", "timeseries", 16, y, 8, 7,
    [T("pg_longest_query_max_duration_seconds", "{{pg_node}}")],
    fieldConfig=FC(unit="s", thr=[{"color":"green","value":None},{"color":"yellow","value":30},{"color":"red","value":300}]),
    description="Duration of longest active query")); y += 7

# === ROW: LOCKS AND CONFLICTS ===
panels.append(R("LOCKS AND CONFLICTS", y)); y += 1

panels.append(P("Locks by Mode", "timeseries", 0, y, 12, 7,
    [T("pg_locks_summary_count", "{{pg_node}} {{datname}} {{mode}}")]))

panels.append(P("Conflicts and Deadlocks", "timeseries", 12, y, 12, 7,
    [T("rate(pg_database_activity_conflicts[5m])", "conflicts {{pg_node}} {{datname}}", "A"),
     T("rate(pg_database_activity_deadlocks[5m])", "deadlocks {{pg_node}} {{datname}}", "B")],
    fieldConfig=FC(unit="ops"))); y += 7

# === ROW: TABLE HEALTH ===
panels.append(R("TABLE HEALTH AND VACUUM", y)); y += 1

panels.append(P("Dead Tuples (top tables)", "timeseries", 0, y, 12, 7,
    [T("topk(10, pg_table_stats_n_dead_tup)", "{{pg_node}} {{relname}}")],
    description="Vacuum pressure indicator"))

panels.append(P("Live vs Dead Tuples", "timeseries", 12, y, 12, 7,
    [T("topk(10, pg_table_stats_n_live_tup)", "live {{relname}}", "A"),
     T("topk(10, pg_table_stats_n_dead_tup)", "dead {{relname}}", "B")])); y += 7

panels.append(P("HOT Update Ratio", "timeseries", 0, y, 12, 7,
    [T("rate(pg_table_stats_n_tup_hot_upd[5m]) / (rate(pg_table_stats_n_tup_upd[5m]) + 0.001) * 100",
       "{{pg_node}} {{relname}}")],
    fieldConfig=FC(unit="percent"),
    description="Higher = better. HOT avoids index updates."))

panels.append(P("Table Sizes (top)", "bargauge", 12, y, 12, 7,
    [T("topk(15, pg_table_sizes_total_bytes)", "{{relname}}", instant=True)],
    fieldConfig=FC(unit="bytes"),
    options={"orientation": "horizontal", "displayMode": "gradient"})); y += 7

panels.append(P("Sequential vs Index Scans", "timeseries", 0, y, 12, 7,
    [T("rate(pg_table_stats_seq_scan[5m])", "seq {{relname}}", "A"),
     T("rate(pg_table_stats_idx_scan[5m])", "idx {{relname}}", "B")],
    fieldConfig=FC(unit="ops"),
    description="High seq_scan may indicate missing indexes"))

panels.append(P("Autovacuum Run Count", "timeseries", 12, y, 12, 7,
    [T("pg_table_stats_autovacuum_count", "{{pg_node}} {{relname}}")])); y += 7

# === ROW: DATABASE SIZE ===
panels.append(R("DATABASE SIZE", y)); y += 1

panels.append(P("Database Size (trend)", "timeseries", 0, y, 12, 7,
    [T('pg_database_size_bytes{datname!~"template.*"}', "{{instance}} {{datname}}")],
    fieldConfig=FC(unit="bytes"),
    description="From default postgres_exporter metrics"))

panels.append(P("Database Size (current)", "bargauge", 12, y, 12, 7,
    [T('pg_database_size_bytes{datname!~"template.*"}', "{{instance}} {{datname}}", instant=True)],
    fieldConfig=FC(unit="bytes"),
    options={"orientation": "horizontal", "displayMode": "gradient"})); y += 7

# === ROW: CONNECTION UTILISATION ===
panels.append(R("CONNECTION UTILISATION", y)); y += 1

panels.append(P("Connection Utilisation %", "gauge", 0, y, 8, 7,
    [T("sum by (pg_node) (pg_connection_states_count) / on(pg_node) pg_settings_info_max_connections * 100",
       "{{pg_node}}")],
    fieldConfig=FC(unit="percent", mn=0, mx=100,
        thr=[{"color":"green","value":None},{"color":"yellow","value":70},{"color":"red","value":90}]),
    description="Percentage of max_connections in use"))

panels.append(P("Max Connections Setting", "stat", 8, y, 4, 7,
    [T("pg_settings_info_max_connections", "{{pg_node}}")],
    fieldConfig=FC(decimals=0)))

panels.append(P("Is Replica", "stat", 12, y, 4, 7,
    [T("pg_replication_is_replica", "{{pg_node}}")],
    fieldConfig=FC(mappings=[{"type":"value","options":{"1":{"text":"REPLICA","color":"blue"},"0":{"text":"PRIMARY","color":"green"}}}])))

panels.append(P("WAL Position (bytes)", "stat", 16, y, 8, 7,
    [T("pg_replication_wal_position_bytes", "{{pg_node}}")],
    fieldConfig=FC(unit="bytes"))); y += 7

# === ROW: ETCD CLUSTER ===
panels.append(R("ETCD CLUSTER", y)); y += 1

panels.append(P("etcd Leader Changes", "timeseries", 0, y, 8, 7,
    [T("rate(etcd_server_leader_changes_seen_total[5m])", "{{instance}}")],
    fieldConfig=FC(unit="ops"),
    description="Should be near zero"))

panels.append(P("etcd Proposals", "timeseries", 8, y, 8, 7,
    [T("rate(etcd_server_proposals_committed_total[5m])", "committed {{instance}}", "A"),
     T("rate(etcd_server_proposals_failed_total[5m])", "failed {{instance}}", "B"),
     T("etcd_server_proposals_pending", "pending {{instance}}", "C")],
    fieldConfig=FC(unit="ops")))

panels.append(P("etcd DB Size", "timeseries", 16, y, 8, 7,
    [T("etcd_debugging_mvcc_db_total_size_in_bytes", "{{instance}}")],
    fieldConfig=FC(unit="bytes"))); y += 7

panels.append(P("etcd WAL Fsync p99", "timeseries", 0, y, 12, 7,
    [T("histogram_quantile(0.99, rate(etcd_disk_wal_fsync_duration_seconds_bucket[5m]))", "p99 {{instance}}")],
    fieldConfig=FC(unit="s"),
    description="Should be under 10ms"))

panels.append(P("etcd gRPC Rate", "timeseries", 12, y, 12, 7,
    [T("rate(grpc_server_started_total[5m])", "{{grpc_method}}")],
    fieldConfig=FC(unit="ops"))); y += 7


# Assemble dashboard
dashboard = {
    "annotations": {"list": []},
    "editable": True,
    "fiscalYearStartMonth": 0,
    "graphTooltip": 1,
    "id": None,
    "links": [],
    "panels": panels,
    "refresh": "10s",
    "schemaVersion": 39,
    "tags": ["postgresql", "patroni", "ha", "etcd", "replication"],
    "templating": {
        "list": [
            {
                "name": "DS_PROMETHEUS",
                "type": "datasource",
                "query": "prometheus",
                "current": {"text": "Prometheus", "value": "Prometheus"},
            }
        ]
    },
    "time": {"from": "now-1h", "to": "now"},
    "timepicker": {"refresh_intervals": ["5s", "10s", "30s", "1m", "5m"]},
    "timezone": "browser",
    "title": "PostgreSQL HA Cluster - Patroni / etcd / HAProxy",
    "uid": "pg-ha-patroni-cluster",
    "version": 3,
}

os.makedirs(os.path.dirname(DASHBOARD_OUT), exist_ok=True)
with open(DASHBOARD_OUT, 'w', newline='\n') as f:
    json.dump(dashboard, f, indent=2)
print(f"Dashboard: {len(panels)} panels written to {DASHBOARD_OUT}")
