# PostgreSQL High-Availability Cluster

## Patroni + etcd + HAProxy + Prometheus + Grafana on Docker for Windows

A production-style HA PostgreSQL lab environment running entirely in Docker Desktop.
12 containers managed as a single stack via Docker Compose.

---

## Architecture Overview

```
                    ┌─────────────────────────────────────────────┐
                    │           CLIENT APPLICATIONS               │
                    │  psql -h localhost -p 5000 -U postgres      │
                    └──────────┬──────────────┬───────────────────┘
                               │              │
                        Write :5000     Read :5001
                               │              │
                    ┌──────────┴──────────────┴───────────────────┐
                    │              HAProxy                         │
                    │  Health checks Patroni REST API (:8008)     │
                    │  Write → /primary (200 = leader only)       │
                    │  Read  → /replica (200 = standbys only)     │
                    │  Stats dashboard at :7000                    │
                    └────┬─────────────┬─────────────┬────────────┘
                         │             │             │
              ┌──────────┴──┐  ┌──────┴───────┐  ┌──┴──────────┐
              │  patroni1   │  │  patroni2    │  │  patroni3   │
              │  PG :5432   │  │  PG :5432    │  │  PG :5432   │
              │  API :8008  │  │  API :8008   │  │  API :8008  │
              │  (LEADER)   │  │  (REPLICA)   │  │  (REPLICA)  │
              └──────┬──────┘  └──────┬───────┘  └──────┬──────┘
                     │                │                  │
              ┌──────┴──────┐  ┌──────┴───────┐  ┌──────┴──────┐
              │   etcd1     │  │   etcd2      │  │   etcd3     │
              │   :2379     │◄─┤   :2379      ├─►│   :2379     │
              │             │  │              │  │             │
              └─────────────┘  └──────────────┘  └─────────────┘
                     Distributed Consensus (Raft Protocol)
```

### Monitoring Stack

```
   patroni1:8008 ──┐                    ┌── pg-exporter1 ──┐
   patroni2:8008 ──┼── /metrics ──►     │   (→ patroni1)   │
   patroni3:8008 ──┘                    ├── pg-exporter2 ──┼──► Prometheus ──► Grafana
                                        │   (→ patroni2)   │      :9090        :3000
   etcd1:2379 ─────┐                    ├── pg-exporter3 ──┘
   etcd2:2379 ─────┼── /metrics ──►     │   (→ patroni3)
   etcd3:2379 ─────┘                    │
                                        └──────────────────
```

**Key design decision:** 3 separate postgres_exporters (one per PostgreSQL node)
instead of 1 through HAProxy. This ensures we collect metrics from **both the
primary and replicas**, including replica-specific stats like replication lag
and WAL receive positions.

---

## Component Summary

| Component | Image | Version | Purpose |
|-----------|-------|---------|---------|
| **etcd** | `gcr.io/etcd-development/etcd` | v3.5.27 | Distributed key-value store. Stores Patroni cluster state and handles leader election via Raft consensus. 3 nodes for quorum. |
| **Patroni** | Custom (built from `postgres:17`) | 4.1.0 | PostgreSQL HA manager. Runs on each PG node, manages replication, handles automatic failover, exposes REST API for health checks. |
| **PostgreSQL** | Bundled in Patroni image | 17 | The database. One primary (read-write) and two streaming replicas (read-only). Patroni manages the lifecycle. |
| **HAProxy** | `haproxy:3.1` | 3.1 | TCP load balancer. Routes write traffic to the primary, read traffic across replicas. Uses Patroni REST API for backend health. |
| **postgres_exporter** | `prometheuscommunity/postgres-exporter` | latest | Converts PostgreSQL system views into Prometheus metrics. Custom queries add deep-dive stats. |
| **Prometheus** | `prom/prometheus` | latest | Time-series database. Scrapes metrics from Patroni, pg_exporters, and etcd every 10-15 seconds. |
| **Grafana** | `grafana/grafana` | latest | Visualisation. Pre-provisioned with Prometheus datasource and a 40+ panel dashboard. |

---

## Port Map

| Service | Host Port | Container Port | Protocol | Purpose |
|---------|-----------|----------------|----------|---------|
| HAProxy Write | **5000** | 5000 | TCP/PostgreSQL | Connect here for read-write queries |
| HAProxy Read | **5001** | 5001 | TCP/PostgreSQL | Connect here for read-only queries |
| HAProxy Stats | **7000** | 7000 | HTTP | HAProxy dashboard |
| patroni1 PG | 5433 | 5432 | TCP/PostgreSQL | Direct access (bypass HAProxy) |
| patroni2 PG | 5434 | 5432 | TCP/PostgreSQL | Direct access |
| patroni3 PG | 5435 | 5432 | TCP/PostgreSQL | Direct access |
| patroni1 API | 8008 | 8008 | HTTP/REST | Patroni REST API |
| patroni2 API | 8009 | 8008 | HTTP/REST | Patroni REST API |
| patroni3 API | 8010 | 8008 | HTTP/REST | Patroni REST API |
| etcd1 | 2379 | 2379 | HTTP/gRPC | etcd client API |
| etcd2 | 2381 | 2379 | HTTP/gRPC | etcd client API |
| etcd3 | 2383 | 2379 | HTTP/gRPC | etcd client API |
| pg-exporter1 | 9187 | 9187 | HTTP | Prometheus metrics (patroni1) |
| pg-exporter2 | 9188 | 9187 | HTTP | Prometheus metrics (patroni2) |
| pg-exporter3 | 9189 | 9187 | HTTP | Prometheus metrics (patroni3) |
| Prometheus | **9090** | 9090 | HTTP | Prometheus web UI |
| Grafana | **3000** | 3000 | HTTP | Grafana dashboards |

---

## Quick Start

### Prerequisites

- Docker Desktop for Windows with WSL2 backend
- Minimum 8GB RAM allocated to Docker (Settings → Resources)
- ~5GB free disk space

### Setup (One Command)

```cmd
patroni-ha-cluster.cmd setup
```

This will:
1. Create directory structure under `BASE_DIR`
2. Generate TLS certificates (CA + server/client certs)
3. Generate Patroni, HAProxy, Prometheus, Grafana configs
4. Generate custom postgres_exporter queries
5. Generate `docker-compose.yml`
6. Build the Patroni Docker image (first run: ~3-5 minutes)
7. Start all 12 containers via `docker compose up -d`

### Verify

```cmd
REM Check cluster status
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml list

REM Expected output:
REM + Cluster: pg-ha-cluster ---+----+-----------+
REM | Member   | Host     | Role    | State     | TL | Lag in MB |
REM +----------+----------+---------+-----------+----+-----------+
REM | patroni1 | patroni1 | Leader  | running   |  1 |           |
REM | patroni2 | patroni2 | Replica | streaming |  1 |         0 |
REM | patroni3 | patroni3 | Replica | streaming |  1 |         0 |
REM +----------+----------+---------+-----------+----+-----------+

REM Connect to the cluster
psql -h localhost -p 5000 -U postgres -d postgres
```

---

## Step-by-Step Guide

For learning purposes, you can bring up the cluster layer by layer:

### Step 1: Generate Everything

```cmd
patroni-ha-cluster.cmd generate
```

Examine the generated files:
- `config\patroni1.yml` — Patroni YAML for node 1
- `config\haproxy\haproxy.cfg` — HAProxy load balancer config
- `config\pg-exporter\queries.yml` — Custom PostgreSQL metrics queries
- `config\prometheus\prometheus.yml` — Prometheus scrape targets
- `docker-compose.yml` — The full Docker Compose definition
- `certs\` — TLS certificates (CA, etcd, PG, HAProxy)

### Step 2: Start etcd

```cmd
patroni-ha-cluster.cmd start-etcd
```

Verify:
```cmd
docker exec etcd1 /usr/local/bin/etcdctl endpoint health ^
  --endpoints=http://etcd1:2379,http://etcd2:2379,http://etcd3:2379
```

**What's happening:** Three etcd nodes form a Raft cluster. They elect a leader
among themselves (not related to the PostgreSQL leader). etcd needs 2 of 3 nodes
for quorum. This is where Patroni stores all cluster metadata.

### Step 3: Start Patroni / PostgreSQL

```cmd
patroni-ha-cluster.cmd start-patroni
```

Wait ~20 seconds, then:
```cmd
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml list
```

**What's happening:**
1. Each Patroni node connects to etcd
2. First node to set the leader key in etcd becomes the primary
3. Primary runs `initdb` to create the PostgreSQL cluster
4. Other nodes use `pg_basebackup` to clone from the primary
5. Replicas start streaming WAL from the primary

### Step 4: Start HAProxy

```cmd
patroni-ha-cluster.cmd start-haproxy
```

Open http://localhost:7000 (admin/HaproxyStats2026) to see backend health.

**What's happening:** HAProxy polls each Patroni node's REST API:
- `GET /primary` returns 200 only from the leader → write backend
- `GET /replica` returns 200 only from standbys → read backend
- If a node is down or switching roles, it returns non-200 and HAProxy marks it down

### Step 5: Start Monitoring

```cmd
patroni-ha-cluster.cmd start-monitoring
```

Open:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/GrafanaAdmin2026)

---

## How Failover Works

```
BEFORE:                          AFTER (patroni1 fails):

patroni1 [LEADER]               patroni1 [DOWN]
  ├─ patroni2 [REPLICA]           patroni2 [LEADER] ◄── promoted
  └─ patroni3 [REPLICA]           └─ patroni3 [REPLICA] ◄── re-pointed

1. patroni1 stops responding
2. Its leader key in etcd expires (TTL: 30s)
3. patroni2 and patroni3 race to acquire the key
4. Winner runs pg_promote() to become new primary
5. Loser reconfigures to stream from new primary
6. HAProxy detects role change via REST API health checks
7. Client connections route to new primary within ~3 seconds

When patroni1 comes back:
8. It detects another node holds the leader key
9. Uses pg_rewind to sync its diverged timeline
10. Starts streaming as a replica from the new primary
```

### Test Failover

```cmd
patroni-ha-cluster.cmd failover-test
```

Or manually:
```cmd
REM See who is leader
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml list

REM Stop the leader
docker compose -p patroni-ha stop patroni1

REM Wait 15 seconds, then check
docker exec -it patroni2 patronictl -c /etc/patroni/patroni.yml list

REM Bring it back (rejoins as replica)
docker compose -p patroni-ha start patroni1
```

---

## Configuration Management

### Changing PostgreSQL Parameters

**DO NOT** edit `postgresql.conf` directly — Patroni overwrites it.

```cmd
REM View current dynamic config (stored in etcd)
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml show-config

REM Edit (opens editor inside container)
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml edit-config

REM After editing, check if restart is needed
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml list
REM Look for "pending restart" flag

REM Rolling restart (one node at a time, no downtime)
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml restart pg-ha-cluster
```

### Configuration Hierarchy

| Level | Source | Scope | Persistence |
|-------|--------|-------|-------------|
| Dynamic (DCS) | `patronictl edit-config` | All nodes | Stored in etcd |
| Local | `patroni.yml` → `postgresql.parameters` | Per node | In config file |
| Bootstrap | `patroni.yml` → `bootstrap.dcs` | Initial only | Used once at init |

---

## Monitoring: Grafana Dashboard

The pre-provisioned dashboard has **40+ panels** across these sections:

| Section | Metrics Shown |
|---------|--------------|
| **Cluster Overview** | Node states (running/stopped), leader indicator, timeline, uptime |
| **Replication** | WAL positions, lag in seconds and bytes, WAL file count, streaming detail |
| **Database Activity** | Connections by state per node, TPS (commits/rollbacks), row operations |
| **Performance** | Cache hit ratio (gauge + per-DB), block I/O, checkpoints, buffer writes, temp files |
| **Locks and Conflicts** | Lock types/modes, deadlock rate, replication conflicts |
| **Table Health** | Dead tuples, live vs dead ratio, HOT update ratio, table sizes |
| **Database Size** | Size trends and current size per database |
| **Query Performance** | Top queries by total/mean time (pg_stat_statements) |
| **Long Running Queries** | Currently active queries sorted by duration |
| **etcd Cluster** | Leader changes, Raft proposals, DB size, WAL fsync latency |

### Custom postgres_exporter Queries

Located at `config\pg-exporter\queries.yml`, these extend the default metrics:

| Query | Metrics Added |
|-------|--------------|
| `pg_replication` | Lag seconds, is_replica flag, WAL position per node |
| `pg_stat_replication_detail` | Per-replica write/flush/replay lag in bytes |
| `pg_stat_user_tables_detail` | Full table stats: scans, tuples, dead rows, vacuum counts |
| `pg_stat_statements_detail` | Top 20 queries by time with call counts and buffer stats |
| `pg_lock_detail` | Lock counts by database, type, and mode |
| `pg_long_running_queries` | Active queries with duration and SQL preview |
| `pg_table_bloat` | Table/index sizes for bloat analysis |
| `pg_wal_info` | WAL file count and total size on disk |

---

## File Structure

```
D:\Software\Containers\PostgresPatroni\Claude\
├── patroni-ha-cluster.cmd          ← This management script
├── README.md                       ← This documentation
├── docker-compose.yml              ← Generated Docker Compose file
│
├── config\
│   ├── patroni1.yml                ← Patroni config (node 1)
│   ├── patroni2.yml                ← Patroni config (node 2)
│   ├── patroni3.yml                ← Patroni config (node 3)
│   ├── haproxy\
│   │   └── haproxy.cfg             ← HAProxy load balancer config
│   ├── pg-exporter\
│   │   └── queries.yml             ← Custom PostgreSQL metrics queries
│   ├── prometheus\
│   │   └── prometheus.yml          ← Prometheus scrape config
│   └── grafana\
│       ├── provisioning\
│       │   ├── datasources\
│       │   │   └── datasource.yml  ← Auto-configures Prometheus datasource
│       │   └── dashboards\
│       │       └── provider.yml    ← Points Grafana to dashboard JSON
│       └── dashboards\
│           └── pg-ha-cluster.json  ← The 40+ panel dashboard
│
├── certs\                          ← TLS certificates (auto-generated)
│   ├── ca.crt / ca.key             ← Certificate Authority
│   ├── etcd-server.crt / .key      ← etcd server certificate
│   ├── etcd-peer.crt / .key        ← etcd peer-to-peer certificate
│   ├── etcd-client.crt / .key      ← Client cert for Patroni→etcd
│   ├── pg-server.crt / .key        ← PostgreSQL server certificate
│   └── haproxy.crt / .key          ← HAProxy certificate
│
├── patroni-image\                  ← Patroni Docker build context
│   ├── Dockerfile
│   └── entrypoint.sh
│
├── pgdata\                         ← PostgreSQL data (HOST MAPPED)
│   ├── patroni1\                   ← Node 1 PGDATA
│   ├── patroni2\                   ← Node 2 PGDATA
│   └── patroni3\                   ← Node 3 PGDATA
│
├── etcd-data\                      ← etcd persistent data
│   ├── etcd1\
│   ├── etcd2\
│   └── etcd3\
│
├── prometheus-data\                ← Prometheus TSDB
└── grafana-data\                   ← Grafana state (dashboards, users)
```

---

## Useful Commands

```cmd
REM === PATRONI ===
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml list
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml show-config
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml edit-config
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml history
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml switchover
docker exec -it patroni1 patronictl -c /etc/patroni/patroni.yml restart pg-ha-cluster

REM === ETCD ===
docker exec etcd1 etcdctl endpoint health --endpoints=http://etcd1:2379,http://etcd2:2379,http://etcd3:2379
docker exec etcd1 etcdctl member list -w table --endpoints=http://etcd1:2379
docker exec etcd1 etcdctl get --prefix /service/pg-ha-cluster --endpoints=http://etcd1:2379

REM === POSTGRESQL (via HAProxy) ===
psql -h localhost -p 5000 -U postgres -c "SELECT pg_is_in_recovery();"
psql -h localhost -p 5000 -U postgres -c "SELECT * FROM pg_stat_replication;"
psql -h localhost -p 5000 -U postgres -c "SELECT * FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 10;"

REM === DOCKER COMPOSE ===
docker compose -p patroni-ha ps
docker compose -p patroni-ha logs -f --tail 100 patroni1
docker compose -p patroni-ha stop
docker compose -p patroni-ha start
docker compose -p patroni-ha down --remove-orphans
```

---

## Credentials

| Service | Username | Password | Notes |
|---------|----------|----------|-------|
| PostgreSQL superuser | `postgres` | `SuperSecret2026` | Full access |
| PostgreSQL replication | `replicator` | `ReplSecret2026` | Streaming replication |
| PostgreSQL app user | `appuser` | `AppSecret2026` | Created at bootstrap |
| HAProxy stats | `admin` | `HaproxyStats2026` | http://localhost:7000 |
| Grafana | `admin` | `GrafanaAdmin2026` | http://localhost:3000 |

**Change these** in the `CONFIGURATION` section of `patroni-ha-cluster.cmd` before
running setup in any shared or non-isolated environment.

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| etcd won't start | Stale data from previous cluster | Delete `etcd-data\` folders, re-run setup |
| Patroni stuck "creating replica" | etcd not ready | Check etcd health, ensure all 3 nodes are up |
| HAProxy shows all backends red | Patroni hasn't finished init | Wait 30s; check `patronictl list` |
| pg-exporter connection refused | PG not ready on that node | Exporter retries automatically; wait 30s |
| Ports 8009/8010 not responding | Old containers from non-compose run | Run option 9 (remove), then option 1 (setup) |
| "Data directory has wrong ownership" | Windows volume permission issue | Delete `pgdata\patroniX\` folder for that node |
| Dashboard shows "No data" | Prometheus hasn't scraped yet | Wait 30s; check Prometheus targets at :9090 |

## Using Standard Grafana Community Dashboards

Standard PostgreSQL dashboards from [grafana.com/dashboards](https://grafana.com/grafana/dashboards/)
work with this setup because the Prometheus config uses:

- **`job_name: "postgres"`** — matches what most community dashboards expect
- **`relabel_configs`** — rewrites `instance` from the exporter address
  (`pg-exporter1:9187`) to the actual PostgreSQL server (`patroni1:5432`)
  so dashboard template variables populate correctly

### Recommended Community Dashboards

Import these via Grafana UI (+ → Import → paste ID):

| Dashboard ID | Name | Notes |
|-------------|------|-------|
| **9628** | PostgreSQL Database | Most popular. Works out of the box. |
| **14114** | PostgreSQL Exporter Quickstart | Good overview with connection pool stats. |
| **12273** | PostgreSQL (pgwatch) | Detailed per-query performance. |
| **455** | Postgres Overview | Classic simple overview. |

After importing, select **Prometheus** as the datasource and the `instance`
dropdown should show `patroni1:5432`, `patroni2:5432`, `patroni3:5432`.

### If a Specific Dashboard Still Shows "No data"

1. Check what `job` value the dashboard expects:
   - In Grafana, edit the dashboard → Variables → look at the query for `$job`
   - If it expects something other than `"postgres"`, edit the variable default

2. Check metric names — some dashboards use older metric name formats.
   Open Prometheus at http://localhost:9090 and search for the metric name
   used in the failing panel to verify it exists.

3. Some dashboards need `--auto-discover-databases` (already enabled in our
   setup) to collect per-database metrics.
